package lab10_1;
public class Subject implements Evaluation
{
    private String subjName;
    private int score[];
    
    public Subject (String name, int[] score)
    {
        this.subjName = name;
        this.score = score;
    }
    
    @Override
    public double evaluate()
    {
        int sum = 0;
        for (int i = 0; i<score.length;)
        {
            sum += score[i];
            i++;
        }
        return sum/score.length;
    }
    
    @Override
    public char grade(double avgScore)
    {
        if (avgScore >= 70) {return 'P';}
        else return'F';
    }
    
    @Override
    public String toString()
    {
        return subjName;
    }
}
