package lab10_2;

import java.util.ArrayList;

public class BusTester 
{
    public static void main(String[] args) 
    {
        ArrayList<Bus> arr = new ArrayList<Bus>();
        
        Hybrid hbB = new Hybrid(45,1.2,610,150,1);
        arr.add(hbB);
        
        CNGBus cngB = new CNGBus(50,1,200,2);
        arr.add(cngB);
        
        for (int i = 0; i<arr.size();)
        {
            System.out.println("ID : "+arr.get(i).getID());
            if (arr.get(i) instanceof CNGBus)
            {
                CNGBus bus = (CNGBus) arr.get(i);
                System.out.println("Emission tier : "+bus.getEmissionTier());
            }
            if (arr.get(i) instanceof Hybrid)
            {
                Hybrid bus = (Hybrid) arr.get(i);
                System.out.println("Emission tier : "+bus.getEmissionTier());
            }           
            System.out.println("Accel : "+arr.get(i).getAccel());
            
            i++;
        }
    }
    
}
