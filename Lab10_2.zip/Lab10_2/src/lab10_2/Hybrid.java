package lab10_2;
public class Hybrid extends Bus implements LiquidFuel, Electric
{
    private double voltage;
    private double range;
    private int emissionTier;
    
    public Hybrid (int capacity, double cost, double voltage, double range, int tier)
    {
        super(capacity, cost);
        if(voltage > HIGH_VOLTAGE){this.voltage = HIGH_VOLTAGE;}
        else voltage = LOW_VOLTAGE;
        this.range = range;
        this.emissionTier = tier;
    }
    
    @Override
    public double getAccel(){return 4.0;}

    @Override
    public double getRange(){return range;}
    
    @Override
    public int getEmissionTier(){return emissionTier;}
    
    @Override
    public double getVoltage(){return voltage;}
}
