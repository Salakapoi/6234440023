package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue 
{
    private ArrayList<String> queue = new ArrayList<String>();
    
    public MusicBox ()
    {
        
    }
    
    @Override
    public void enqueue (Object o)
    {
        String song = (String) o;
        queue.add(song);
        System.out.println(song +" is added in queue");
    }
    
    @Override
    public void dequeue ()
    {
        System.out.println("Now playing : "+queue.get(0));
        queue.remove(0);
    }
}
