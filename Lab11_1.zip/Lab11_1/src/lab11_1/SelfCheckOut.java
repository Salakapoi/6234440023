package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue
{
    private ArrayList<Product> cart = new ArrayList<Product>();
    double sum;
    
    public SelfCheckOut ()
    {
        
    }
    
    @Override
    public void enqueue (Object o)
    {
        Product goods = (Product) o;
        cart.add(goods);
        System.out.println(goods.getName() +" is added in queue");
    }
    
    @Override
    public void dequeue ()
    {
        sum += cart.get(0).getPrice();
        cart.remove(0);
    }
    
    public double getAmount ()
    {
        return sum;
    }
}
