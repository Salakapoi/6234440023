package lab12_1;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileTester 
{
    public static void main(String[] args) throws FileNotFoundException 
    {
        String word = "";
        Writer out = new Writer();
        
        while (!word.equals("quit"))
        {
            Scanner input = new Scanner(System.in);
            word = input.nextLine();
            out.addLine(word); 
        }
        
        Reader in = new Reader();
        System.out.println("Total characters : "+in.char_count);
        System.out.println("Total words : "+in.word_count);
        System.out.println("Total lines : "+in.line_count);
    }
}
