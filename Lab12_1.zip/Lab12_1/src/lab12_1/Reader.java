package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Reader 
{
    String text;
    ArrayList <String> words = new ArrayList <String>();
    int line_count = 0;
    int word_count = 0;
    int char_count = 0;
    
    public Reader () throws FileNotFoundException
    {
        File file = new File ("Text.txt");
        Scanner input = new Scanner(file);
        
        while(input.hasNextLine())
        {
            text = input.nextLine();
            line_count++;
            word_count += text.split(" ").length;
            char_count += +text.split(" ").length - 1;
            
            for (int i =0; i < text.split(" ").length; i++)
            {
                words.add(text.split(" ")[i]);    
            }
            for (int j = 0; j < words.size(); j++)
                {
                    char_count += words.get(j).length();
                }
            words.clear();
        }
        input.close();
    }
    
    public int getLines()
    {
        return line_count;
    }
    
    public int getWords()
    {
        return word_count;
    }
    
    public int getchar()
    {
        return char_count;
    }
}
