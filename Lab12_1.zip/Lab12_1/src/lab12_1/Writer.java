package lab12_1;

import java.io.*;
import java.io.PrintWriter;

public class Writer 
{ 
    private PrintWriter output;
    
    public Writer () throws FileNotFoundException
    {
       File file = new File("Text.txt");
       output = new PrintWriter(file); 
    }
    
    public void addLine (String word) 
    {
        if (!word.equals("quit"))
        {
            output.println(word);
        }
        else 
            output.close();  
    }
}
