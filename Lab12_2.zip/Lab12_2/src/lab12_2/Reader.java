package lab12_2;

import java.util.ArrayList;
import java.util.Scanner;

public class Reader
{
    private ArrayList <String> wordlist = new ArrayList <>();
    private String word = "";
    private ArrayList <String> word_not_contained = new ArrayList <>();
    
    public Reader (Scanner in)
    {
        while (in.hasNextLine())
        {
            word = in.nextLine();
            wordlist.add(word);
        }
    }
    
    public String notContain(String input)
    {
        String notContained = "";
        String[] in = input.split(" ");
        
        for (int i = 0; i < in.length; i++)
        {
            for (int j = 0; j < wordlist.size(); j++)
            {
                if (wordlist.get(j).equalsIgnoreCase(in[i]) || word_not_contained.contains(in[i]))
                {
                    break;
                }
                if (!wordlist.get(j).equalsIgnoreCase(in[i]) && j == wordlist.size()-1)
                {
                    notContained += in[i]+"\n";
                    word_not_contained.add(in[i]);
                }
            }
        }
        
        if(notContained.isBlank())
        {
            return "N/A";
        }
        else
        {
            return notContained;
        }
    }
}
