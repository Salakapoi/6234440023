package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordList {     
        
    public static void main(String[] args) {
        
        File file = new File("wordlist.txt");
        Scanner list = null ;
        
        try 
        {
            list = new Scanner(file);
            Reader wordlist = new Reader(list);
            
            System.out.print("Enter a sentence: ");
            Scanner in = new Scanner(System.in);
            String input = in.nextLine();
            
            System.out.println("Words not contained: ");
            System.out.println(wordlist.notContain(input));
        }
        
        catch(FileNotFoundException e)
        {
            System.out.println(e);
            list.close();
        }
        
    }
    
}
