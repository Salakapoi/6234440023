package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class FileMatch 
{
    private int accNo;
    private String name;
    private double balance, amount;
    private static ArrayList <AccountRecord> accounts = new ArrayList<>();
    private static ArrayList <TransactionRecord> trans = new ArrayList<>();
    
    public static void main(String[] args) 
    {
        File master_file = new File("master.xt");
        File trans_file = new File("trans.txt");
        
        try (Scanner master_in = new Scanner(master_file))
        {
            FileMatch master = new FileMatch(master_in);
            
            try (Scanner trans_in = new Scanner(trans_file))
            {
                FileMatch trans = new FileMatch(trans_in);
            }
            
            for (int i = 0; i < trans.size(); i++)
            {
                for (int j = 0; j < accounts.size(); j++)
                {
                    if (accounts.get(j).getAcctNo() == trans.get(i).getAcctNo())
                    {
                        accounts.get(j).combine(trans.get(i));
                    }
                }
            }
            
            try (PrintWriter output = new PrintWriter("newMaster.dat"))
            {
                for (int i = 0; i < accounts.size(); i++)
                {
                    output.print(accounts.get(i).getAcctNo());
                    output.print(accounts.get(i).getName());  
                    if (accounts.get(i).getName().length() < 30)
                    {
                        for (int j = 0; j < 30 - accounts.get(i).getName().length(); j++){output.print(" ");}
                    }
                    output.print(accounts.get(i).getBalance());
                    output.println(accounts.get(i).getTransCnt());
                }
            }
            
            File new_master_file = new File("newMaster.dat");
            try (Scanner new_master_in = new Scanner(new_master_file))
            {
                int acc_cnt = 0;
                double tot_balance = 0;
                int no_trans_cnt = 0;
                while (new_master_in.hasNextLine())
                {
                    String accDetails = new_master_in.nextLine();
                    acc_cnt++;
                    double balance = Double.parseDouble(accDetails.substring(33, accDetails.length()-1));
                    int trans_cnt = Integer.parseInt(accDetails.substring(accDetails.length()-1));
                    tot_balance += balance;
                    if (trans_cnt == 0) {no_trans_cnt++;}
                }
                System.out.println("Total Account Record : " + acc_cnt);
                System.out.println("Total Balance : " + tot_balance);
                System.out.println("No transaction : " + no_trans_cnt + " account.");
                new_master_in.close();
            }
        }
        
        catch (FileNotFoundException e) 
        {
            System.out.println(e);
        }  
    }
    
    public FileMatch (Scanner in)
    {
        while(in.hasNextLine())
        {
            String[] text = in.nextLine().split(" ");
            if (text.length == 4)
            {
                accNo = Integer.parseInt(text[0]);
                name = text[1]+" "+text[2];
                balance = Double.parseDouble(text[3]);
                AccountRecord account = new AccountRecord(accNo,name,balance);
                accounts.add(account);
            }
            else if(text.length == 2)
            {
                accNo = Integer.parseInt(text[0]);
                amount = Double.parseDouble(text[1]);
                TransactionRecord account = new TransactionRecord(accNo,amount);
                trans.add(account);
            }
        }
        in.close();
    }
}
