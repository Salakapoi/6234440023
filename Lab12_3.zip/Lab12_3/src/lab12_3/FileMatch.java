package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileMatch 
{
    private int accNo;
    private String name;
    private double balance, amount;
    private static ArrayList <AccountRecord> accounts = new ArrayList<>();
    private static ArrayList <TransactionRecord> trans = new ArrayList<>();
    
    public static void main(String[] args) 
    {
        File master_file = new File("master.txt");
        File trans_file = new File("trans.txt");
        
        try (Scanner master_in = new Scanner(master_file))
        {
            FileMatch master = new FileMatch(master_in);
            
            try (Scanner trans_in = new Scanner(trans_file))
            {
                FileMatch trans = new FileMatch(trans_in);
            }
            
            for (int i = 0; i < trans.size(); i++)
            {
                for (int j = 0; j < accounts.size(); j++)
                {
                    if (accounts.get(j).getAcctNo() == trans.get(i).getAcctNo())
                    {
                        accounts.get(j).combine(trans.get(i));
                    }
                }
            }
            
            try (RandomAccessFile output = new RandomAccessFile("newMaster.dat","rw"))
            {
                for (int i = 0; i < accounts.size(); i++)
                {
                    output.writeInt(accounts.get(i).getAcctNo());
                    output.writeChars(accounts.get(i).getName()); 
                    if (accounts.get(i).getName().length() < 30)
                    {
                        for (int j = 0; j < 30 - accounts.get(i).getName().length(); j++){output.writeChar(' ');}
                    }
                    output.writeChar('\n');
                    output.writeDouble(accounts.get(i).getBalance());
                    output.writeInt(accounts.get(i).getTransCnt());
                }
                output.close();
            } 
            catch (FileNotFoundException ex) 
            {
                System.out.println("Error! File not found!");
            } catch (IOException ex) {
                Logger.getLogger(FileMatch.class.getName()).log(Level.SEVERE, null, ex);
            }
 
            try (RandomAccessFile new_master = new RandomAccessFile("newMaster.dat","r"))
            {
                int acc_cnt = (int) (new_master.length()/80);
                double tot_balance = 0;
                int no_trans_cnt = 0;
                for (int i = 0; i < acc_cnt; i++)
                {
                    new_master.readLine();
                    tot_balance += new_master.readDouble();
                    int trans = new_master.readInt();
                    if (trans == 0) { no_trans_cnt++; }
                }
                new_master.close();
                
                System.out.println("Total Account Record : " + acc_cnt);
                System.out.println("Total Balance : " + tot_balance);
                System.out.println("No transaction : " + no_trans_cnt + " account."); 
            } catch (IOException ex) {
                Logger.getLogger(FileMatch.class.getName()).log(Level.SEVERE, null, ex);
            }            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileMatch.class.getName()).log(Level.SEVERE, null, ex);
        }       
    }            
    public FileMatch (Scanner in)
    {
        while(in.hasNextLine())
        {
            String[] text = in.nextLine().split(" ");
            if (text.length == 4)
            {
                accNo = Integer.parseInt(text[0]);
                name = text[1]+" "+text[2];
                balance = Double.parseDouble(text[3]);
                AccountRecord account = new AccountRecord(accNo,name,balance);
                accounts.add(account);
            }
            else if(text.length == 2)
            {
                accNo = Integer.parseInt(text[0]);
                amount = Double.parseDouble(text[1]);
                TransactionRecord account = new TransactionRecord(accNo,amount);
                trans.add(account);
            }
        }
        in.close();
    }
}   
