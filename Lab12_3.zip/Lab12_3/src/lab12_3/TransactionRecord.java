package lab12_3;

public class TransactionRecord
{ 
    private int acctNo;
    private double trans_amount;

    public TransactionRecord (int acctNo, double amount) 
    {
        this.acctNo = acctNo;
        this.trans_amount = amount;
    }
    
    public int getAcctNo() 
    { 
        return acctNo; 
    }
    
    public double getTransactionAmount()
    { 
        return trans_amount; 
    }
}
