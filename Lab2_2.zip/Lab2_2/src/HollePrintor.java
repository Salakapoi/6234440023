/**
 *
 * @author usci
 */
public class HollePrintor 
{

    public static void main(String[] args) 
    {
      String Word = "Hello, World!";
      String NewWord_O = Word.replace("o", "O");
      String NewWord_o = NewWord_O.replace("e","o");
      String NewWord = NewWord_o.replace("O", "e");
      System.out.println(NewWord);
    }
    
}
