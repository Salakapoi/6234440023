
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Gregorian 
{
    public static void main(String[] args) 
    {
        GregorianCalendar Today = new GregorianCalendar(2020,Calendar.JANUARY, 20);
        Today.add(Calendar.DAY_OF_MONTH, 100);
        int dayOfMonth = Today.get(Calendar.DAY_OF_MONTH);
        int month = Today.get(Calendar.MONTH);
        int year = Today.get(Calendar.YEAR);
        int weekday = Today.get(Calendar.DAY_OF_WEEK);
                
        System.out.println(weekday+" "+dayOfMonth+" "+month+' '+year+' ');
        
        GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.APRIL, 2);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int dayOfMonth_B = myBirthday.get(Calendar.DAY_OF_MONTH);
        int month_B = myBirthday.get(Calendar.MONTH);
        int year_B = myBirthday.get(Calendar.YEAR);
        int weekday_B = myBirthday.get(Calendar.DAY_OF_WEEK);
        
        System.out.println(weekday_B+" "+dayOfMonth_B+" "+month_B+' '+year_B+' ');
    }
    
}
