package lab3.pkg1;
public class InsectPopulation
{
    private double size;
    public  double getNumInsect;
    
    public void Constructor (double constructor)
    {
        this.size = constructor;
    }
    
    public void Breed ()
    {
        size = 2 * size;
    }
    
     public void Spray ()
    {
        size = size * 90 / 100;
    }
     
      public double GetNumInsect ()
    {
        this.getNumInsect = size;
        return getNumInsect;
    }
 
}
