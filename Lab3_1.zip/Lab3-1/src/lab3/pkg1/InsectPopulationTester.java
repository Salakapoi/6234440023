package lab3.pkg1;
public class InsectPopulationTester 
{
    public static void main(String[] args)
    {
        InsectPopulation A = new InsectPopulation();
        A.Constructor (10) ;
        A.Breed();
        A.Spray();
        A.GetNumInsect();
        System.out.println("Number of insects: "+A.getNumInsect);
        
        InsectPopulation B = new InsectPopulation();
        B.Constructor (A.getNumInsect) ;
        B.Breed();
        B.Spray();
        B.GetNumInsect();
        System.out.println("Number of insects: "+B.getNumInsect);
        
        InsectPopulation C = new InsectPopulation();
        C.Constructor (B.getNumInsect) ;
        C.Breed();
        C.Spray();
        C.GetNumInsect();
        System.out.println("Number of insects: "+C.getNumInsect);
    }
}