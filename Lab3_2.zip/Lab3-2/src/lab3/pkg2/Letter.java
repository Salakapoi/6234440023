package lab3.pkg2;
public class Letter 
{
    private final String Sender;
    private final String Reciever;
    private String Contents = "";
    private String letter;
    
    public Letter(String from, String to)
    {
        Sender = from;
        Reciever = to;
    }
    
    public void addLine(String line)
    {
        Contents = Contents+"\n"+line;
    }
    
    public String getText()
    {
        letter = "Dear "+Reciever+":\n"+Contents+"\n\nSincerely,\n\n"+Sender;
        return letter;
    }
       
}
