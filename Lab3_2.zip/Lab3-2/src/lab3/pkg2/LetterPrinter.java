package lab3.pkg2;

public class LetterPrinter 
{
    public static void main(String[] args)
    {
        Letter A = new Letter("Clarissa" ,"Jade");
        A.addLine("We must find Simon quickly.");
        A.addLine("He might be in danger.");
        A.getText();
        System.out.print(A.getText());
    }  
}
