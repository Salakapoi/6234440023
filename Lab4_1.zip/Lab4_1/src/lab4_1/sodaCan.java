package lab4_1;
public class sodaCan 
{
    private double canHeight;
    private double canRadius;
    private double canVolume;
    private double canSurface;
    
    public void height (double height)
    {
        canHeight = height;
    }
    
    public void diameter (double diameter)
    {
        canRadius = diameter/2.0;
    }
    
    public double getVolume ()
    {
        canVolume = Math.PI*canRadius*canRadius*canHeight;
        canVolume = (Math.round(canVolume*100))/100.00;
        return canVolume;
    }
    
    public double getSurfaceArea ()
    {
        canSurface = (2*Math.PI*canRadius*canRadius)+(2*Math.PI*canRadius*canHeight);
        canSurface = (Math.round(canSurface*100))/100.00;
        return canSurface;
    }
    
}
