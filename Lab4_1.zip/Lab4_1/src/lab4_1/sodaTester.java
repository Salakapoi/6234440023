package lab4_1;
import java.util.Scanner;
public class sodaTester 
{
    public static void main(String[] args) 
    {
        Scanner canProperties = new Scanner(System.in);
        System.out.print("Enter height: ");
        double Height = canProperties.nextDouble();
        System.out.print("Enter diameter: ");
        double Diameter = canProperties.nextDouble();
       
        sodaCan Can = new sodaCan ();
        Can.height(Height);
        Can.diameter(Diameter);
        System.out.println("Volume: "+Can.getVolume());
        System.out.println("Surface area: "+Can.getSurfaceArea());
    }
}
