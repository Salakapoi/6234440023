package lab4_2;
public class DigitExtractor
{
    private int integer;
    private int Digit;
    
    public DigitExtractor(int anInteger) 
    {
       integer = anInteger;
    }
    
    public int nextDigit() 
    {
        Digit = integer%10;
        integer = integer/10;
        return Digit;
    }
}
