package lab4_3;
public class TimeInterval 
{
    private final int initialTime;
    private final int finalTime;
    private final int timeDifferrence;
    
    public TimeInterval (int Initial ,int Final)
    {
        initialTime = (Initial/100*60)+(Initial%100);
        finalTime = (Final/100*60)+(Final%100);
        timeDifferrence = finalTime - initialTime;
    }
    
    public int getHours ()
    {
        return timeDifferrence/60;
    }
    
    public int getMinutes ()
    {
        return timeDifferrence%60;
    }
}
