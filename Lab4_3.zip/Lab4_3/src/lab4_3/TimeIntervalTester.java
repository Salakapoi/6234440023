package lab4_3;
import java.util.Scanner;
public class TimeIntervalTester 
{
    public static void main(String[] args) 
    {
        Scanner Initial = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int iTime = Initial.nextInt();
        Scanner Final = new Scanner(System.in);
        System.out.print("Enter end time: ");
        int fTime = Final.nextInt();
        
        TimeInterval Time = new TimeInterval(iTime,fTime);
        System.out.println(Time.getHours()+" hours "+Time.getMinutes()+" minutes.");
        
    }
    
}
