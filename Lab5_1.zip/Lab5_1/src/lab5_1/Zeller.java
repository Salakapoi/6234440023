package lab5_1;
public class Zeller 
{
    private static int dayOfMonth;
    private static int month;
    private static int year;
    public enum Day 
    {
        SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), 
        WEDNESDAY("Wednesday"), THURSDAY("Thursday"), FRIDAY("Friday"), 
        SATURDAY("Saturday");
    
        private final String dayOfWeek;
        Day(String dayOfweek) 
        {   
            this.dayOfWeek = dayOfweek;
        }
        
        public String DayOfWeek() { return dayOfWeek; }
    }
    
    public static void Date (int Year, int Month, int DayOfMonth)
    {
        dayOfMonth = DayOfMonth;
        month = Month;
        year = Year;
        if (month == 1 || month == 2)
        {
            month = month + 12;
            year = year - 1;
        }
    }
    
    public static Day getDayOfWeek()
    {
        int h = ((dayOfMonth) + ((26*(month + 1))/10) + (year%100) + ((year%100)/4) + ((year/100)/4) + (5*(year/100)))%7;
        Day dayOfWeek = null;
        
        if (h == 0)
            dayOfWeek = Day.SATURDAY;
        if (h == 1)
            dayOfWeek = Day.SUNDAY;
        if (h == 2)
            dayOfWeek = Day.MONDAY;
        if (h == 3)
            dayOfWeek = Day.TUESDAY;
        if (h == 4)
            dayOfWeek = Day.WEDNESDAY;
        if (h == 5)
            dayOfWeek = Day.THURSDAY;
        if (h == 6)
            dayOfWeek = Day.FRIDAY;
        
        return dayOfWeek;
    }  
}
