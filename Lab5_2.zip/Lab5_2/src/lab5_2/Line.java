package lab5_2;

import java.awt.geom.Point2D;

public class Line 
{
    private final double m;
    private final double b;
    private final double x;
    
    public Line(double x, double y, double m) // y-y1 = m(x-x1)
    {
        this.m = m;
        b = (m*(-x))+y;
        if (m == 0.0)
        {
            this.x = 0.0/0.0;
        }
        else
            this.x = ((-y)/m)+x;
    }
    public Line(double x1, double y1, double x2, double y2) // y-y1/x-x1 = y2-y1/x2-x1
    {
        m = (y2-y1)/(x2-x1);
        b = (m*(-x1))+y1;
        if (m == 0.0)
        {
            x = 0.0/0.0;
        }
        else
            x = ((-y1)/m)+x1;
    }
    public Line(double m, double b) // y = mx+b
    {
        this.b = b;
        this.m = m;
        if (m == 0.0)
        {
            x = 0.0/0.0;
        }
        else
        {
           x = (-b)/m; 
        }        
    }
    public Line(double a) // x = a
    {
        x = a;
        m = 0.0/0.0;
        b = 0.0/0.0;
    }
    
    public boolean isParallel(Line line) 
    {
        return m == line.m;
    }
    public boolean equals(Line line) 
    {
        return (m == line.m)&&(b==line.b)&&(x==line.x);
    }
    public boolean isIntersect(Line line) 
    {
        return (m != line.m);
    }
    
    public Point2D.Double getIntersectionPoint(Line line) 
    {
        Double M = m;
        Double LineM = line.m;
        Double B = b;
        Double xIntersect = x;
        Double LineXIntersect = line.x;
        double X = (b-line.b)/(line.m-m);
        
        if (M.isNaN())
            X = x;
        if (LineM.isNaN())
            X = line.x;
        double Y = (m*X) + b;
        
        if (M.isNaN())
            if (B.isNaN())
            Y = (line.m*X) + line.b;
            else
                Y = (line.m*X) + b;
        else if (xIntersect.isNaN())
            Y = b;
        else if (LineXIntersect.isNaN())
            Y = line.b;
        
        return new Point2D.Double(X,Y);
    }
        
}
