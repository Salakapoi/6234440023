package lab5_2;

public class LineTester 
{
    public static void main(String[] args) 
    {
        Line l1 = new Line(-2,1,1,-2);
        Line l2 = new Line(-6,-2,-2,0); 
   
        System.out.println("Are the two lines equals?: "+ l2.equals(l1));
        System.out.println("Are the two lines parallel?: "+ l2.isParallel(l1));
        System.out.println("Do the two lines intersect?: "+ l2.isIntersect(l1));
        if (l2.isParallel(l1) == false)
            System.out.println("Point of intersection: "+ (Math.round(l2.getIntersectionPoint(l1).getX()*100.00)/100.00) + "," + Math.round(l2.getIntersectionPoint(l1).getY()*100.00)/100.00);
    }
}
