package lab6_2;

import java.util.Random;
import java.util.Scanner;

public class Game 
{
    String user;
    String pc;
    String result;
    int computer = 0;
    int player = 0;
    boolean gameHasEnded = false;
    
    
    public void play()
    {
        while (gameHasEnded == false)
        {        
            Scanner input = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            int play = input.nextInt();
        
            if (play == 0 || play == 1 || play == 2)
            {
                if (play == 0) {user = "ROCK";}
                else if (play == 1) {user = "PAPER";}
                else {user = "SCISSOR";}
                
                Random rand = new Random();
                int com = rand.nextInt(3);
                if (com == 0) {pc = "ROCK";}
                else if (com == 1) {pc = "PAPER";}
                else {pc = "SCISSOR";}
                
                System.out.println("You enter: "+user);
                System.out.println("Computer: "+pc);
                
                if(user == "ROCK" && pc == "ROCK")
                {
                    result = "It's a tie.";
                }
                else if(user == "ROCK" && pc == "PAPER")
                {
                    result = "You lose!";
                    computer += 1;
                }
                else if(user == "ROCK" && pc == "SCISSOR")
                {
                    result = "You win!";
                    player += 1;
                }
                else if(user == "PAPER" && pc == "ROCK")
                {
                    result = "You win!";
                    player += 1;
                }
                else if(user == "PAPER" && pc == "PAPER")
                {
                    result = "It's a tie.";
                }
                else if(user == "PAPER" && pc == "SCISSOR")
                {
                    result = "You lose!";
                    computer += 1;
                }
                else if(user == "SCISSOR" && pc == "ROCK")
                {
                    result = "You lose!";
                    computer += 1;
                }
                else if(user == "SCISSOR" && pc == "PAPER")
                {
                    result = "You win!";
                    player += 1;
                }
                else if(user == "SCISSOR" && pc == "SCISSOR")
                {
                    result = "It's a tie.";
                }
                System.out.println(result);
                
                if ((player - computer) == 2)
                {
                    gameHasEnded = true;
                    System.out.println("----------------------------------------");
                    System.out.println("Congrats! You win.");
                    
                }
                if ((computer - player) == 2)
                {
                    gameHasEnded = true;
                    System.out.println("----------------------------------------");
                    System.out.println("Too bad! You lose.");
                    
                }
            }              
        }        
        System.out.println("User Score: "+player);
        System.out.println("Computer score: "+computer);
    }    
}

