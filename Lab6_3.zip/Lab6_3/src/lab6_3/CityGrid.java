
package lab6_3;

import java.util.Random;

public class CityGrid
{
    private int xCoor;
    private int yCoor;
    private int gridSize;
    
    public CityGrid(int width, int lenght)
    {
        yCoor = width/2;
        xCoor = lenght/2;
        gridSize = width*lenght;
    }
    
    public void walk()
    {
        Random rand = new Random();
        int way = rand.nextInt(4);
        
        if (way == 0) {yCoor += 1;}
        else if (way == 1) {yCoor -= 1;}
        else if (way == 2) {xCoor -= 1;}
        else if (way == 3) {xCoor += 1;}
    }
    
    public boolean isInCity(int width, int lenght)
    {
        return (yCoor <= width)&&(yCoor >= 0)&&(xCoor <= lenght)&&(xCoor >= 0);
    }

    public void reset(int width, int lenght)
    {
       yCoor = width/2;
       xCoor = lenght/2; 
    }
    
    
    
}
