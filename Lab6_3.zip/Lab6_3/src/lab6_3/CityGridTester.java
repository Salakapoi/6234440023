
package lab6_3;

public class CityGridTester 
{
    public static void main(String[] args) 
    {
        CityGrid city = new CityGrid(10,10);
        int distance = 0;
        int sets = 0;
        float outOfBound = 0;
        int distanceInCity = 0;
        int totalDistance = 0;
        int maximumDistance = 0;
        float inCityAverage = 0;
        
        while(sets < 10000)
        {    
            if (city.isInCity(10, 10))
                {
                    city.walk();
                    distance += 1;
                    distanceInCity += 1;
                    totalDistance += 1;
                
                    if (distance == 1000) 
                        {
                            sets += 1;
                            distance = 0;
                        }
                }
            else 
            {
                if (distanceInCity > maximumDistance ) 
                {
                    distanceInCity -= 1;
                    maximumDistance = distanceInCity;
                }
                outOfBound += 1;
                distanceInCity = 0;
                city.reset(10, 10);
            }    
        }
        
        inCityAverage = totalDistance/outOfBound;
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f",inCityAverage);
        System.out.println("");
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+maximumDistance);   
    }
}
