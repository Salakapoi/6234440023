package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EndGame extends AppCompatActivity
{
    public void replayTheGame()
    {
        Intent intent = new Intent(EndGame.this,TopPage.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_game);

        Button replay = (Button) findViewById(R.id.Replay);
        replay.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                replayTheGame();
            }
        });
    }
}
