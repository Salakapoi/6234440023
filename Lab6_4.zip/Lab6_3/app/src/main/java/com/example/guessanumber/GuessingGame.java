package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class GuessingGame extends AppCompatActivity
{
    public void endTheGame()
    {
        Intent intent = new Intent(GuessingGame.this,EndGame.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guessing_game);

        Random rand = new Random();
        final int number = rand.nextInt(100) + 1;

        Button guess = (Button) findViewById(R.id.guess);
        guess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                boolean  gameEnded = false;

                TextView hint = (TextView) findViewById(R.id.hint);

                if (gameEnded == false)
                {
                    EditText playerInput = (EditText) findViewById(R.id.playerInput);
                    int playerGuess = Integer.parseInt(playerInput.getText().toString());

                    if (playerGuess == number)
                    {
                        gameEnded = true;
                        endTheGame();
                    }
                    else if (playerGuess < number) {hint.setText("Your guess is too low");}
                    else if (playerGuess > number) {hint.setText("Your guess is too high");}
                }

            }
        });




    }
}
