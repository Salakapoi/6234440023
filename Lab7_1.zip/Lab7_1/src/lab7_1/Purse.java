package lab7_1;

import java.util.ArrayList;


public class Purse 
{   
   ArrayList<String> purse = new ArrayList<>();
   ArrayList<String> purseReversed = new ArrayList<>();

    public void addCoin(String coinName)
    {
        purse.add(coinName);
    }
    
   @Override
    public String toString()
    {
        return "Purse"+purse;
    }
    
    public ArrayList<String> reverse()
    {
        int i = 0 ;
        while (i < purse.size())
        {
            purseReversed.add(purse.get((purse.size()-1)-i));
            i+=1;
         }
        return purseReversed;
    }
    
    public void transfer(Purse other)
    {
         int i = 0;
         while(i<purse.size())
         {    
            other.addCoin(purse.get(i));
            purse.remove(i);
         }
    }
    
    private ArrayList<String> arrayList ()
    {
        return purse;
    }
    
    public boolean sameContents(Purse other)
    {
            boolean same = true;
            
            if (other.arrayList().size() == purse.size())
            {
                int i = 0;
                while ( i < purse.size())
                {
                    if (other.arrayList().get(i) != purse.get(i)) {same = false;}
                    i += 1;
                }
            }
            else {same = false;}
        
        return same;
    }
    
    public boolean sameCoins(Purse other)
    {
        boolean same = false;
        
        String coin = "";
                
        int quarter1 = 0;
        int dime1 = 0;
        int nickel1 = 0;
        int penny1 = 0;
        
        int quarter2 = 0;
        int dime2 = 0;
        int nickel2 = 0;
        int penny2 = 0;
        
         int i = 0;
         while(i < purse.size())
         {    
             coin = purse.get(i);
             if (coin == "Quarter") {quarter1 +=1;}
             else if (coin == "Nickel") {nickel1 +=1;}
             else if (coin == "Dime") {dime1 +=1;}
             else if (coin == "Penny") {penny1 +=1;}
             
             coin = other.arrayList().get(i);
             if (coin == "Quarter") {quarter2 +=1;}
             else if (coin == "Nickel") {nickel2 +=1;}
             else if (coin == "Dime") {dime2 +=1;}
             else if (coin == "Penny") {penny2 +=1;}
             
             i += 1;
         } 
         
             if ((quarter1 == quarter2)&&(nickel1 == nickel2)&&(dime1 == dime2)&&(penny1 == penny2)) 
             { same = true;}
                
        return same;
    }
    
}
