package lab7_1;

public class PurseTester 
{
    public static void main(String[] args) 
    {
        Purse purseA = new Purse();       
        purseA.addCoin("Quarter");
        purseA.addCoin("Dime");
        purseA.addCoin("Nickel");
        purseA.addCoin("Dime");      
        System.out.println("PurseA: "+purseA.toString());
        System.out.println("PurseA revresed: "+purseA.reverse());
        
        Purse purseB = new Purse();
        purseB.addCoin("Quarter");
        System.out.println("purseB: "+purseB);
        
        purseA.transfer(purseB);
        System.out.println("purseA after transfer: "+purseA);
        System.out.println("purseB after transfer: "+purseB);
        
        Purse purseC = new Purse();
        purseC.addCoin("Quarter");
        purseC.addCoin("Dime");
        purseC.addCoin("Nickel");
        
        Purse purseD = new Purse();
        purseD.addCoin("Quarter");
        purseD.addCoin("Nickel");
        purseD.addCoin("Dime");
        
        System.out.println("purseC: "+purseC);
        System.out.println("purseD: "+purseD);
        System.out.println("is purse C same contents with purseD?: "+purseC.sameContents(purseD));
        System.out.println("is purse C same coins with purseD?: "+purseC.sameCoins(purseD));
    }
}
