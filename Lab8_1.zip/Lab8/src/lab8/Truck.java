package lab8;
public class Truck extends Car 
{
    private final double M_weight;
    private double weight;
    
    public Truck (double gas, double efficiency, double MaxWeight, double weight)
    {
        super(gas,efficiency);
        this.M_weight = MaxWeight;
        this.weight = weight;
        
        if (weight > M_weight) {this.weight = M_weight;}
    }
    
    @Override 
    public void drive(double distance)
    {
        double requiredGas = distance/super.getEfficiency();
        if(weight > 20) {requiredGas += (requiredGas*30.0)/100.0;}
        else if (weight > 10) {requiredGas += (requiredGas*20.0)/100.0;}
        else if (weight >= 1) {requiredGas += (requiredGas*10.0)/100.0;}
        
        if (requiredGas > super.getGas()) {System.out.println("You cannot drive too far, please add gas");}
        else {super.setGas(super.getGas() - requiredGas);}
        
    }
}
