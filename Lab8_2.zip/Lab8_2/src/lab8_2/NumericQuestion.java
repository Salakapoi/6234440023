package lab8_2;
public class NumericQuestion extends Question 
{
    public NumericQuestion (String text)
    {
        super(text);
    }
    
    @Override
    public boolean checkAnswer(String response)
    {
        double ans = Double.parseDouble(getAnswer());
        double res = Double.parseDouble(response);
        double epsilon = Math.abs(ans-res);
        return(epsilon < 0.01);
    }
}
