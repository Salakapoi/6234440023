package lab8_2;
public class Question 
{
    private String text;
    private String answer;
    
    public Question()
    {
        
    }
    
    public Question (String quiz)
    {
        this.text = quiz;
    }
    
    public void setText (String question)
    {
        this.text = question;
    }
    
    public void setAnswer (String ans)
    {
        this.answer = ans;
    }
    
    public String getText()
    {
        return text;
    }
    
    public String getAnswer()
    {
        return answer;
    }
    
    public boolean checkAnswer(String response)
    {
        return(answer.equals(response));
    }
    
    public void display()
    {
        System.out.println(text);
    }
}
