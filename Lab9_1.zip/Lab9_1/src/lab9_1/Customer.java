package lab9_1;
public class Customer 
{
    private String name, tel;
    
    public Customer (String name, String tel)
    {
        this.name = name;
        this.tel = tel;
    }
    
    public double getDiscount()
    {
        return 0.0;
    }
    
    @Override
    public String toString()
    {
        return name+" Tel : "+tel;
    }
}
