package lab9_1;

import java.util.ArrayList;

public class Order 
{
    public static int cntOrder = 0; // auto generate order's id
    private int id;     
    private Customer c;     
    private ArrayList<Pizza> p = new ArrayList<Pizza>(); 
    
    public Order (Customer customer)
    {
        this.c = customer;
        cntOrder++;
        this.id = cntOrder;
    }
    
    public void addPizza(Pizza pizza)
    {
        p.add(pizza);
    }
    
    public String getOrderDetail()
    {
        String orderID = "Order id : "+id+"\n";
        String pizzaDetail = "";
        for (int i = 0; i < p.size();) 
        {
            pizzaDetail += p.get(i).toString()+"\n";
            i++;
        }
        return orderID+c.toString()+"\n"+pizzaDetail+"Total pieces : "+p.size()+"\n"+"Total cost : "+calculatePayment();
    }
    
    public double calculatePayment()
    {
        double price = 0.0;
        for (int i = 0; i < p.size();) 
        {
            price += p.get(i).getPrice();
            i++;
        }
        double discount = c.getDiscount()/100.00;
        price -= price*discount;
        return price;
    }
}
