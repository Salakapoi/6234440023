package lab9_2;
public class cosine extends Taylor
{
    public cosine (int k, int x)
    {
        super.setIter(k);
        super.setValue(x);
    }
    
    @Override
    public double getApprox() 
    {
        double cos = 0;
        int n = 0;
        while (n <= super.getIter())
        {
            int a = (2*n);
            cos += ((Math.pow((-1),n))*(Math.pow(super.getValue(), a)/super.factorial(a)));
            n++;
        }
        return cos;
    }
    
    @Override
    public void printValue() 
    {
       System.out.println("Value from Math.cos() is "+Math.cos(super.getValue())+".");
       System.out.println("Approximated value is "+ this.getApprox()+".");
    }
}
