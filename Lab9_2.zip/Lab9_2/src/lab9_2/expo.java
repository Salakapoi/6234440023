package lab9_2;
public class expo extends Taylor 
{    
    public expo (int k, int x)
    {
        super.setIter(k);
        super.setValue(x);
    }
    @Override
    public double getApprox() 
    {
        double exp = 0;
        int n = 0;
        while (n <= super.getIter())
        {
            exp += ((Math.pow(super.getValue(),n))/super.factorial(n));
            n++;
        }
        return exp;
    }
    
    @Override
    public void printValue() 
    {
       System.out.println("Value from Math.exp() is "+Math.exp(super.getValue())+".");
       System.out.println("Approximated value is "+ this.getApprox()+".");
    }
}
