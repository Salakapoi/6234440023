package lab9_2;
public class sine extends Taylor
{
    public sine (int k, double x)
    {
        super.setIter(k);
        super.setValue(x);
    }
    
    @Override
    public double getApprox() 
    {
        double sin = 0;
        double n = 0;
        while (n <= super.getIter())
        {
            int a = (2*(int)n)+1;
            sin += ((Math.pow((-1),n))*(Math.pow(super.getValue(), a)/super.factorial(a)));
            n++;
        }
        return sin;
    }
    
    @Override
    public void printValue() 
    {
       System.out.println("Value from Math.sin() is "+Math.sin(super.getValue())+".");
       System.out.println("Approximated value is "+ this.getApprox()+".");
    }

}
